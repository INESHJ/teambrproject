package towers.model.game_objects

class Wall(val x:Int, val y:Int) {

}
